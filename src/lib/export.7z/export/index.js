const parserWxml = require('./parserWxml')
const {readFile} = require('fs/promises')
const path = require('path')


function matchScripts(source) {
  const matchRegex = /<script>(?<source>[\s\S]+?)<\/script>/m
  const matchResult = []
  const _matchAll = (str) => {
    const r = str.match(matchRegex)
    if (!r || !r.groups) return
    matchResult.push(r.groups.source.trim())
    _matchAll(str.replace(matchRegex, ''))
  }
  _matchAll(source)
  return matchResult.filter(Boolean).join(';\n')
}


(async () => {
  const dir = 'C:\\Users\\0xNoOb\\Desktop\\scope\\test-mod'
  const files = [
    'page-frame.html',
    // 'app-wxss.js',
    // 'page-frame.js',
  ]
  for (const file of files) {
    const source = await readFile(path.join(dir, file), 'utf8')
    const code = file.endsWith('html') ? matchScripts(source) : source
    const data = await parserWxml(code, dir)
    console.log(Object.keys(data))
  }
})()
